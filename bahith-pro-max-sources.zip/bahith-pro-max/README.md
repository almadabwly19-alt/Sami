# الباحث Pro Max: وحدة المصادر + MCP تراث

## المحتوى
- `mcp/TurathMcpClient.kt`: عميل MCP (JSON-RPC عبر HTTP) إلى https://mcp.turath.io/mcp
- `catalog/TurathSource.kt`: بحث نصي كامل في تراث (بلا OCR) وقراءة صفحة
- `catalog/ArchiveSource.kt`: archive.org مقيَّد بالعربية ومرتَّب حسب التحميلات
- `catalog/CatalogRepository.kt`: بحث موحّد متوازٍ مع مهلة وذاكرة مؤقتة
- `text/ArabicNormalizer.kt`: تطبيع التشكيل والهمزات والأرقام

## الدمج (3 خطوات)
1. انسخ المجلد `app/src/main/java/com/bahith/pdf/pro` إلى مشروعك. لا تحتاج مكتبات جديدة (org.json وcoroutines موجودتان).
2. في `AppViewModel.searchCatalog` استبدل استدعاء `ArchiveCatalog.search` بـ:
   ```kotlin
   private val repo = CatalogRepository()
   viewModelScope.launch { catalogResults = repo.search(catalogQuery) }
   ```
3. في شاشة المكتبة اعرض النتائج مجمَّعة حسب المصدر:
   - `downloadablePdf == true` فزر «تحميل وفهرسة» (المسار الحالي).
   - `downloadablePdf == false` فزر «قراءة» يفتح `TurathSource.pageText(bookId, pageId)`، وزر «فتح في تراث» بالرابط `openUrl`.

## ملاحظات مهمة
- خادم MCP لتراث يقرّ بأنه لا يتيح تحميلاً جماعياً، لذا العرض نصي صفحة بصفحة.
- لم يُختبر الاتصال بالشبكة من بيئة الإنشاء (الشبكة معطّلة هناك). اختبره على جهاز أو محاكي.
- هذا يضيف «تراث» وليس «المكتبة الشاملة»: لا يوجد MCP للشاملة متاح لي.
