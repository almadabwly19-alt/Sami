package com.bahith.pdf.pro.catalog

enum class SourceId { ARCHIVE, TURATH }

/** نتيجة موحّدة من أي مصدر. */
data class CatalogHit(
    val source: SourceId,
    val id: String,              // identifier (archive) أو "bookId:pageId" (turath)
    val title: String,
    val author: String? = null,
    val year: String? = null,
    val snippet: String? = null, // نص جاهز بلا OCR (تراث)
    val pageLabel: String? = null,
    val openUrl: String,
    val downloadablePdf: Boolean,
)

interface CatalogSource {
    val id: SourceId
    val displayName: String
    suspend fun search(query: String, page: Int = 1): List<CatalogHit>
}
