package com.bahith.pdf.pro.text

/** تطبيع عربي للبحث: يتحمل التشكيل واختلاف الهمزات وأخطاء OCR الشائعة. */
object ArabicNormalizer {
    private val harakat = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640]")
    private val spaces = Regex("\\s+")

    fun normalize(s: String): String {
        var t = harakat.replace(s, "")
        val sb = StringBuilder(t.length)
        for (c in t) sb.append(
            when (c) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ة' -> 'ه'
                'ؤ' -> 'و'
                'ئ' -> 'ي'
                in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
                in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
                else -> c
            }
        )
        return spaces.replace(sb.toString(), " ").trim()
    }

    /** صيغ بديلة للاستعلام الأصلي (يُرسل الأصل أولاً ثم المطبَّع). */
    fun queryVariants(q: String): List<String> =
        listOf(q.trim(), normalize(q)).filter { it.isNotEmpty() }.distinct()

    fun stripEm(html: String): String =
        html.replace(Regex("</?em>"), "").replace(spaces, " ").trim()
}
