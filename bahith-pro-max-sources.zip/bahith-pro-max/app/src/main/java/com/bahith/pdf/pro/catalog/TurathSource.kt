package com.bahith.pdf.pro.catalog

import com.bahith.pdf.pro.mcp.TurathMcpClient
import com.bahith.pdf.pro.text.ArabicNormalizer
import org.json.JSONArray
import org.json.JSONObject

/** بحث نصي كامل في تراث عبر MCP. لا يوجد PDF: العرض نصي داخل التطبيق. */
class TurathSource(private val mcp: TurathMcpClient = TurathMcpClient()) : CatalogSource {
    override val id = SourceId.TURATH
    override val displayName = "تراث"

    override suspend fun search(query: String, page: Int): List<CatalogHit> {
        val args = JSONObject().put("q", query.take(300)).put("page", page.coerceIn(1, 10))
        val res = mcp.callTool("search_turath", args)
        val arr = res.optJSONArray("results") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val r = arr.getJSONObject(i)
            val m = r.optJSONObject("meta") ?: JSONObject()
            val bookId = r.optInt("book_id", -1)
            val pageId = m.optInt("page_id", -1)
            if (bookId < 0 || pageId < 0) return@mapNotNull null
            CatalogHit(
                source = SourceId.TURATH,
                id = "$bookId:$pageId",
                title = m.optString("book_name").ifEmpty { "كتاب $bookId" },
                author = m.optString("author_name").ifEmpty { null },
                snippet = ArabicNormalizer.stripEm(r.optString("snip")),
                pageLabel = listOfNotNull(
                    m.optString("vol").takeIf { it.isNotEmpty() }?.let { "ج$it" },
                    m.optInt("page", -1).takeIf { it >= 0 }?.let { "ص$it" },
                ).joinToString(" ").ifEmpty { null },
                openUrl = r.optString("link"),
                downloadablePdf = false,
            )
        }
    }

    /** نص صفحة كاملة للقراءة داخل التطبيق. */
    suspend fun pageText(bookId: Int, pageId: Int): String =
        mcp.callTool("get_page", JSONObject().put("book_id", bookId).put("page_id", pageId))
            .let { it.optString("text").ifEmpty { it.toString() } }

    suspend fun bookInfo(bookId: Int): JSONObject =
        mcp.callTool("get_book", JSONObject().put("book_id", bookId))
}
