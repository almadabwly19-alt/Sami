package com.bahith.pdf.pro.catalog

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** archive.org مع تقييد باللغة العربية (نفس نقطة النهاية التي يستخدمها التطبيق الحالي). */
class ArchiveSource : CatalogSource {
    override val id = SourceId.ARCHIVE
    override val displayName = "أرشيف الإنترنت"

    override suspend fun search(query: String, page: Int): List<CatalogHit> = withContext(Dispatchers.IO) {
        val q = URLEncoder.encode("($query) AND (language:ara OR language:Arabic) AND mediatype:texts", "UTF-8")
        val url = "https://archive.org/advancedsearch.php?q=$q" +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=year&fl%5B%5D=downloads" +
            "&sort%5B%5D=downloads+desc&rows=30&page=$page&output=json"
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000; readTimeout = 20_000
            setRequestProperty("User-Agent", "BahithPDF/2.0 (Android; public catalog search)")
        }
        try {
            if (c.responseCode !in 200..299) error("archive.org HTTP ${c.responseCode}")
            val docs = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                .optJSONObject("response")?.optJSONArray("docs") ?: return@withContext emptyList()
            (0 until docs.length()).map { i ->
                val d = docs.getJSONObject(i)
                val ident = d.getString("identifier")
                CatalogHit(
                    source = SourceId.ARCHIVE, id = ident,
                    title = d.optString("title").ifEmpty { ident },
                    author = d.optString("creator").ifEmpty { null },
                    year = d.optString("year").ifEmpty { null },
                    openUrl = "https://archive.org/details/$ident",
                    downloadablePdf = true,
                )
            }
        } finally { c.disconnect() }
    }
}
