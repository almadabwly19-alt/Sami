package com.bahith.pdf.pro.mcp

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * عميل MCP خفيف (Streamable HTTP / JSON-RPC 2.0) بلا مكتبات إضافية.
 * الخادم: https://mcp.turath.io/mcp
 * الأدوات: search_turath, get_page, get_book, get_author, discover_turath
 */
class TurathMcpClient(
    private val endpoint: String = "https://mcp.turath.io/mcp",
    private val timeoutMs: Int = 20_000,
) {
    private val lock = Mutex()
    private var sessionId: String? = null
    private var ready = false
    private var nextId = 1

    suspend fun callTool(name: String, args: JSONObject): JSONObject = withContext(Dispatchers.IO) {
        lock.withLock {
            try {
                ensureInit()
                invoke(name, args)
            } catch (e: SessionExpired) {
                reset(); ensureInit(); invoke(name, args)
            }
        }
    }

    private fun invoke(name: String, args: JSONObject): JSONObject {
        val res = rpc("tools/call", JSONObject().put("name", name).put("arguments", args))
        val result = res.optJSONObject("result") ?: error("MCP: no result ($name)")
        val text = result.optJSONArray("content")?.optJSONObject(0)?.optString("text").orEmpty()
        if (result.optBoolean("isError")) error("MCP tool error: ${text.take(200)}")
        result.optJSONObject("structuredContent")?.let { return it }
        return JSONObject(text.ifEmpty { "{}" })
    }

    private fun ensureInit() {
        if (ready) return
        val params = JSONObject()
            .put("protocolVersion", "2025-03-26")
            .put("capabilities", JSONObject())
            .put("clientInfo", JSONObject().put("name", "BahithPDF").put("version", "2.0"))
        rpc("initialize", params, captureSession = true)
        post(JSONObject().put("jsonrpc", "2.0").put("method", "notifications/initialized"), expectBody = false)
        ready = true
    }

    private fun reset() { ready = false; sessionId = null }

    private fun rpc(method: String, params: JSONObject, captureSession: Boolean = false): JSONObject {
        val id = nextId++
        val body = JSONObject().put("jsonrpc", "2.0").put("id", id).put("method", method).put("params", params)
        val raw = post(body, expectBody = true, captureSession = captureSession)
        val json = parse(raw, id)
        json.optJSONObject("error")?.let { error("MCP error: ${it.optString("message")}") }
        return json
    }

    private fun post(body: JSONObject, expectBody: Boolean, captureSession: Boolean = false): String {
        val c = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true
            connectTimeout = timeoutMs; readTimeout = timeoutMs
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json, text/event-stream")
            setRequestProperty("User-Agent", "BahithPDF/2.0 (Android)")
            sessionId?.let { setRequestProperty("Mcp-Session-Id", it) }
        }
        try {
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (captureSession) c.getHeaderField("Mcp-Session-Id")?.let { sessionId = it }
            if ((code == 404 || code == 400) && sessionId != null) throw SessionExpired()
            if (code !in 200..299) error("MCP HTTP $code")
            return if (expectBody) c.inputStream.bufferedReader().use { it.readText() } else ""
        } finally { c.disconnect() }
    }

    /** يدعم رداً JSON مباشراً أو SSE (أسطر data:). */
    private fun parse(raw: String, id: Int): JSONObject {
        val t = raw.trim()
        if (t.startsWith("{")) return JSONObject(t)
        var last: JSONObject? = null
        for (line in t.lineSequence()) {
            if (!line.startsWith("data:")) continue
            val j = runCatching { JSONObject(line.removePrefix("data:").trim()) }.getOrNull() ?: continue
            if (j.optInt("id", -1) == id) return j
            last = j
        }
        return last ?: error("MCP: empty response")
    }

    private class SessionExpired : RuntimeException()
}
