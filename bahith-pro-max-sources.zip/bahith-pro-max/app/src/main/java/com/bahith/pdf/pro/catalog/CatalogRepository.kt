package com.bahith.pdf.pro.catalog

import com.bahith.pdf.pro.text.ArabicNormalizer
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeout

data class SourceResult(val source: SourceId, val hits: List<CatalogHit>, val error: String? = null)

/** بحث موحّد متوازٍ عبر كل المصادر، فشل مصدر لا يُسقط الباقي. */
class CatalogRepository(
    private val sources: List<CatalogSource> = listOf(TurathSource(), ArchiveSource()),
    private val timeoutMs: Long = 25_000,
) {
    private val cache = object : LinkedHashMap<String, List<SourceResult>>(32, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, List<SourceResult>>?) = size > 40
    }

    suspend fun search(query: String, page: Int = 1, only: Set<SourceId>? = null): List<SourceResult> {
        val q = ArabicNormalizer.queryVariants(query).firstOrNull() ?: return emptyList()
        val key = "$q|$page|${only?.sorted()}"
        synchronized(cache) { cache[key] }?.let { return it }
        val out = coroutineScope {
            sources.filter { only == null || it.id in only }.map { s ->
                async {
                    runCatching { withTimeout(timeoutMs) { s.search(q, page) } }
                        .fold({ SourceResult(s.id, it) }, { SourceResult(s.id, emptyList(), it.message ?: "خطأ") })
                }
            }.awaitAll()
        }
        if (out.any { it.error == null }) synchronized(cache) { cache[key] = out }
        return out
    }
}
