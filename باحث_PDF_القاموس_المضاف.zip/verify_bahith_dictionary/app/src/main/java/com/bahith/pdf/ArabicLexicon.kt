package com.bahith.pdf

import android.content.Context
import java.io.File
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap

/**
 * قاموس OCR عربي قابل للتوسعة:
 * - يحمل الكلمات من assets/arabic_lexicon.tsv ومن ملفات إضافية في filesDir/lexicon.
 * - لا يستبدل كلمة لمجرد أنها غير موجودة في القاموس؛ فالأسماء وألفاظ الرواية قد تكون نادرة.
 * - يصحح فقط صيغاً مؤكدة ومحددة لعبارات OCR الشائعة.
 * صيغة الملف: كلمة واحدة في كل سطر، أو (الصيغة الخاطئة\tالصيغة الصحيحة) للتصحيحات المؤكدة.
 */
object ArabicLexicon {
    private val words = ConcurrentHashMap.newKeySet<String>()
    private val exactFixes = ConcurrentHashMap<String, String>()
    @Volatile private var loaded = false

    @Synchronized
    fun initialize(context: Context) {
        if (loaded) return
        try {
            context.assets.open("arabic_lexicon.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { parseLine(it) }
            }
        } catch (_: Exception) { }
        try {
            val dir = File(context.filesDir, "lexicon")
            if (dir.exists()) dir.listFiles()?.filter { it.isFile && it.extension.lowercase() in setOf("txt", "tsv", "dic") }
                ?.forEach { f -> f.bufferedReader(Charsets.UTF_8).useLines { lines -> lines.forEach { parseLine(it) } } }
        } catch (_: Exception) { }
        // تصحيحات مغلقة لا تُطبّق إلا على تطابق العبارة كاملة بعد التطبيع.
        addFix("ملسو هيلع هللا ىلص", "صلى الله عليه وسلم")
        addFix("ملسو هيلع", "عليه وسلم")
        addFix("هللا ىلص", "صلى الله")
        loaded = true
    }

    private fun parseLine(line: String) {
        val value = line.trim()
        if (value.isEmpty() || value.startsWith("#")) return
        val cols = value.split('\t', limit = 2)
        if (cols.size == 2) addFix(cols[0], cols[1])
        else words.add(key(value))
    }

    private fun key(s: String): String = Arabic.normalize(Normalizer.normalize(s, Normalizer.Form.NFKC))

    private fun addFix(from: String, to: String) {
        val k = key(from)
        if (k.isNotBlank() && to.isNotBlank()) exactFixes[k] = to
    }

    /** تصحيح العبارات التي لها مقابل مؤكد فقط؛ بقية النص يبقى كما قرأه OCR. */
    fun correctHighConfidence(text: String): String {
        if (text.isBlank() || exactFixes.isEmpty()) return text
        var out = text
        for ((bad, good) in exactFixes) {
            val normalized = key(out)
            if (normalized == bad) return good
        }
        return out
    }

    fun contains(word: String): Boolean = key(word) in words
    fun size(): Int = words.size

    /** استيراد قاموس إضافي من داخل التطبيق مستقبلاً، مع إبقاء الملفات المحلية دون اتصال. */
    @Synchronized
    fun importFile(context: Context, source: File): Int {
        val dir = File(context.filesDir, "lexicon")
        dir.mkdirs()
        val target = File(dir, source.name)
        source.copyTo(target, overwrite = true)
        var before = words.size
        target.bufferedReader(Charsets.UTF_8).useLines { lines -> lines.forEach { parseLine(it) } }
        return words.size - before
    }
}
