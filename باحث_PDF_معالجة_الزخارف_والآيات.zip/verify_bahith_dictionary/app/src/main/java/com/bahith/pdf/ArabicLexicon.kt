package com.bahith.pdf

import android.content.Context
import java.io.File
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/**
 * طبقة معالجة عربية للنصوص المستخرجة من PDF وOCR.
 * تحفظ النص العادي كما هو، وتوحّد العبارات الدينية المعروفة فقط عند التطابق
 * أو التقارب العالي جداً؛ ولا تستبدل كلمات منفردة حتى لا تفسد أسماء الرواة.
 * يمكن توسيع الكلمات والتصحيحات بملفات محلية داخل filesDir/lexicon.
 */
object ArabicLexicon {
    private val words = ConcurrentHashMap.newKeySet<String>()
    private val exactFixes = ConcurrentHashMap<String, String>()
    private val sacredPhrases = linkedMapOf(
        "بسم الله الرحمن الرحيم" to listOf("بسم الله الرحمن الرحيم", "بسم الله الرحمان الرحيم"),
        "صلى الله عليه وسلم" to listOf("صلى الله عليه وسلم", "صل الله عليه وسلم", "صلى الله علية وسلم", "ملسو هيلع هللا ىلص", "ملسو هيلع", "ﷺ"),
        "عليه الصلاة والسلام" to listOf("عليه الصلاة والسلام", "عليه الصلاه والسلام"),
        "رضي الله عنه" to listOf("رضي الله عنه", "رضى الله عنه"),
        "رضي الله عنها" to listOf("رضي الله عنها", "رضى الله عنها"),
        "رضي الله عنهما" to listOf("رضي الله عنهما"),
        "رضي الله عنهم" to listOf("رضي الله عنهم"),
        "رحمه الله" to listOf("رحمه الله", "رحمة الله"),
        "رحمهم الله" to listOf("رحمهم الله"),
        "غفر الله له" to listOf("غفر الله له"),
        "سبحانه وتعالى" to listOf("سبحانه وتعالى", "سبحانة وتعالى"),
        "جل جلاله" to listOf("جل جلاله"),
        "الحمد لله رب العالمين" to listOf("الحمد لله رب العالمين"),
        "قل هو الله أحد الله الصمد" to listOf("قل هو الله أحد الله الصمد", "قل هو الله احد الله الصمد"),
        "إن الله على كل شيء قدير" to listOf("إن الله على كل شيء قدير", "ان الله على كل شيء قدير"),
        "والله غفور رحيم" to listOf("والله غفور رحيم"),
        "إن الله غفور رحيم" to listOf("إن الله غفور رحيم", "ان الله غفور رحيم"),
        "لا إله إلا الله" to listOf("لا إله إلا الله", "لا اله الا الله")
    )
    private val phraseKeys: List<Pair<String, String>> by lazy {
        sacredPhrases.flatMap { (canonical, variants) -> variants.map { key(it) to canonical } }
            .distinctBy { it.first }
    }
    @Volatile private var loaded = false

    @Synchronized
    fun initialize(context: Context) {
        if (loaded) return
        try {
            context.assets.open("arabic_lexicon.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.forEach { parseLine(it) }
            }
        } catch (_: Exception) { }
        try {
            val dir = File(context.filesDir, "lexicon")
            if (dir.exists()) dir.listFiles()?.filter { it.isFile && it.extension.lowercase() in setOf("txt", "tsv", "dic") }
                ?.forEach { f -> f.bufferedReader(Charsets.UTF_8).useLines { lines -> lines.forEach { parseLine(it) } } }
        } catch (_: Exception) { }
        // أخطاء OCR معروفة لعبارة الصلاة، بما فيها انقلاب ترتيب الكلمات.
        addFix("ملسو هيلع هللا ىلص", "صلى الله عليه وسلم")
        addFix("هللا ىلص", "صلى الله")
        loaded = true
    }

    private fun parseLine(line: String) {
        val value = line.trim()
        if (value.isEmpty() || value.startsWith("#")) return
        val cols = value.split('\t', limit = 2)
        if (cols.size == 2) addFix(cols[0], cols[1]) else words.add(key(value))
    }

    private fun key(s: String): String = Arabic.normalize(Normalizer.normalize(s, Normalizer.Form.NFKC))

    private fun addFix(from: String, to: String) {
        val k = key(from)
        if (k.isNotBlank() && to.isNotBlank()) exactFixes[k] = to
    }

    private fun distance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                cur[j + 1] = minOf(cur[j] + 1, prev[j + 1] + 1, prev[j] + if (a[i] == b[j]) 0 else 1)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    /**
     * تصحيح العبارات المقدسة داخل الفقرة، لا يشترط أن تكون الصفحة كلها عبارة واحدة.
     * التقريب لا يعمل إلا على عبارة متعددة الكلمات وبعتبة مرتفعة، ويترك بقية النص كما هو.
     */
    fun correctHighConfidence(text: String): String {
        if (text.isBlank()) return text
        var out = text
        // أولاً: تصحيحات صريحة كاملة أو متضمنة في السطر.
        for ((bad, good) in exactFixes) {
            if (bad.isNotBlank() && key(out) == bad) return good
        }
        // تطبيع المحارف الخاصة والعبارات التي قرأها OCR بصورة صحيحة تقريباً.
        for ((variant, canonical) in phraseKeys.sortedByDescending { it.first.length }) {
            if (variant.isBlank()) continue
            val normalized = key(out)
            if (normalized == variant) return canonical
        }
        // تقريب محافظ: نفحص نوافذ من 3 إلى 6 كلمات، ولا نغيّر كلمة منفردة.
        val tokens = Regex("[\\p{IsArabic}\\p{M}]+|[^\\p{IsArabic}\\p{M}]+")
        val matches = tokens.findAll(out).toList()
        val wordIdx = matches.indices.filter { matches[it].value.any { c -> c in '\u0621'..'\u064A' } }
        if (wordIdx.isEmpty()) return out
        val replacements = ArrayList<Triple<Int, Int, String>>()
        for ((target, canonical) in phraseKeys) {
            val targetWords = target.split(' ').filter { it.isNotBlank() }
            if (targetWords.size < 3) continue
            for (start in wordIdx.indices) {
                for (count in (targetWords.size - 1)..(targetWords.size + 1)) {
                    val endPos = start + count - 1
                    if (endPos >= wordIdx.size) continue
                    val first = wordIdx[start]
                    val last = wordIdx[endPos]
                    val candidate = key(out.substring(matches[first].range.first, matches[last].range.last + 1))
                    if (candidate.isBlank()) continue
                    val maxLen = max(candidate.length, target.length)
                    if (maxLen < 8) continue
                    val score = 1.0 - distance(candidate, target).toDouble() / maxLen
                    if (score >= 0.84) {
                        replacements.add(Triple(matches[first].range.first, matches[last].range.last + 1, canonical))
                    }
                }
            }
        }
        // تطبيق أطول المطابقات أولاً من نهاية النص حتى لا تتغير الإزاحات.
        for ((start, end, replacement) in replacements.sortedByDescending { it.first }.distinctBy { it.first to it.second }) {
            if (start >= 0 && end <= out.length && start < end) out = out.substring(0, start) + replacement + out.substring(end)
        }
        return out
    }

    fun contains(word: String): Boolean = key(word) in words
    fun size(): Int = words.size

    @Synchronized
    fun importFile(context: Context, source: File): Int {
        val dir = File(context.filesDir, "lexicon")
        dir.mkdirs()
        val target = File(dir, source.name)
        source.copyTo(target, overwrite = true)
        val before = words.size
        target.bufferedReader(Charsets.UTF_8).useLines { lines -> lines.forEach { parseLine(it) } }
        return words.size - before
    }
}
